#include <iostream>
#include <cmath>

using namespace std;

// struct punto con coord e massa di un punto nello spazio
// funz con array di n punti e d>0
// return: somma delle masse dei punti con distanza dall'origine<d

constexpr int n=3;

struct punto{
	double massa;
	double x;
	double y;
	double z;
};

double somma(punto p[n],double d){
	int i=0;
	double distanza=0;
	double somma=0;
	
	while(i<n){
		distanza=sqrt( p[i].x*p[i].x + p[i].y*p[i].y + p[i].z*p[i].z);
		if(distanza< abs(d)){
			somma= somma + p[i].massa;
		}
		
		i++;
	}
	return somma;
}

int main(){
	
	punto pp[n];
	
	int i=0;
	while(i<n){
		cout<<"inserisci un punto in coord cartesiane"<<endl;
		cin>> pp[i].massa>> pp[i].x >> pp[i].y >>pp[i].z;
		i++;
	}
	double dd;
	cout<<"inserisci d"<<endl;
	cin>>dd;
	
	cout<<"ecco la somma: "<< somma(pp,dd)<<endl;
	
	
}
