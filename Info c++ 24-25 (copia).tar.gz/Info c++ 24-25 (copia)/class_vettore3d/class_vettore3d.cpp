#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

//

class vettore3d {
	private:
		double x,y,z;
	public:
		vettore3d(){
			x=0;
			y=0;
			z=0;
		};
		vettore3d(double x0,double y0,double z0){
			x=x0;
			y=y0;
			z=z0;
		};
		double norma(){
			double modulo=sqrt(x*x+y*y+z*z);
			return modulo;
		};
		vettore3d operator +(const vettore3d &due){  //somma
			vettore3d tot;
			tot.x= x+due.x;
			tot.y= y+due.y;
			tot.z= z+due.z;
			return tot;
		};
		vettore3d operator *(double &k){ //vett*k
			vettore3d tot2;
				tot2.x=x*k;
				tot2.y=y*k;
				tot2.z=z*k;
				return tot2;
		};
		vettore3d operator ^(const vettore3d &due){  //vettoriale
			vettore3d tot3;
			tot3.x=y*due.z-z*due.y;
			tot3.y=z*due.x-x*due.z;
			tot3.z=x*due.y-y*due.x;
			return tot3;
		};
		double operator %(const vettore3d &due){  //scalare
			double scalare;
			scalare= x*due.x + y*due.y + z*due.z;
			return scalare;
		};
		friend ostream& operator <<(ostream &s,vettore3d &uno){
			s<<"("<<uno.x<<","<<uno.y<<","<<uno.z<<")";
			return s;
		};
};


int main(){
	
	vettore3d one={1,0,0};
	vettore3d two={0,1,0};
	cout<<one.norma()<<endl;
	
	vettore3d somma=one+two;
	cout<<"somma: "<<somma<<endl;
	
	double k=5;
	vettore3d param=one*k;
	cout<<"vettore*k: "<<param<<endl;
	
	vettore3d vettoriale=one^two;
	cout<<"prod vettoriale: "<<vettoriale<<endl;
	
	double scalare=one%two;
	cout<<"prod scalare: "<<scalare<<endl;
	
	
}
