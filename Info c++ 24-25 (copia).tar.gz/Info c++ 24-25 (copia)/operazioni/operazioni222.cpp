#include <iostream>
#include <cmath>

using namespace std;

int main(){
	string segno[4]={"+","-","*","/"};
	
	double uno,due;
	cout<<"inserisci i due numeri"<<endl;
	cin>>uno>>due;
	
	string operazione;
	cout<<"inserisci segno"<<endl;
	cin>>operazione;
	
	double tot=0;
	
	//bool trovato=false;
	int i=0;
	
	while(i<4){
		if (operazione==segno[i]){
			tot=uno <<operazione <<due;
			
			}
		
		i++;
		}
	
	cout<<tot<<endl;
	
}
