#include <iostream>
#include <cmath>

using namespace std;

int main(){
	double uno,due ;
	string segno;
	
	cout<< "inserisci i due numeri (separati da uno spazio)" << endl;
	cin>>uno>>due;
	
	cout<<"inserisci l'operazione desiderata"<<endl;
	cin>>segno;
	
	double tot=0;
	
	if (due==0 && segno=="/"){
		cout<<"ERRORRRRRRRR"<<endl;
		
	}
	else{
		if (segno=="+"){
			tot=uno+due;
		}
		else if(segno=="-"){
			tot=uno-due;
		}
		else if(segno=="*"){
			tot=uno*due;
		}
		else if(segno=="/"){
			tot=uno/due;
		}
		else{
			cout<<"ERRORRRRRRRRRRR	"<<endl;
		}
		
		cout<<uno<<segno<<due<<"="<<tot<<endl;
	}
}
