#include <iostream>
#include <cmath>

using namespace std;

//calcola la somma dei divisori propri (no 1 e num stesso)

int main(){
	int n;
	cout<<"inserisci un numero intero"<<endl;
	cin>> n;
	cout<<"il tuo numero è: "<< n<<endl;
	
	int somma=0;
	int i=2;
	while(i<=(n/2)){
		if(n%i==0){
			somma=somma+i; 
		}
		i++;
	}
	cout<<somma<<endl;
}
