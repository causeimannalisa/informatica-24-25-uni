#include <iostream>
#include <cmath>

using namespace std;

//leggi un array e scrivi se tutti gli elementi sono uguali

int main(){
	
	constexpr int n=5;
	double dati[n];
	
	cout<<"inserisci array"<<endl;
	
	int i=0;
	while(i<n){
		cin>>dati[i];
		i++;
	}
	
	double x=dati[0];
	i=0;
	string risultato;
	while(dati[i]==x && i<n){
		i++;
	}
	if(i==n){
		cout<<"sono tutti uguali"<<endl;
	}
	else{
		cout<<"non sono tutti uguali"<<endl;
	}
}
