#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

//
constexpr double epsilon=8.854187817*(pow(10,-12));
constexpr double pi=3.14159;
			
class carica_elettrica{
	public:	//modifica con get x e il resto
		double x,y,z;
		double carica;
	public:
		carica_elettrica(double x0, double y0, double z0, double carica0){
			x=x0;
			y=y0;
			z=z0;
			carica=carica0;
		};
		double potenziale(double xp,double yp, double zp){
			double v;
			
			
			double raggio=sqrt(xp*xp+yp*yp+zp*zp);
			
			v=(1/(4*pi*epsilon))*(carica/raggio);
			return v;
		};
		
		
		friend ostream& operator<<(ostream &s, carica_elettrica uno){
			s<<"("<<uno.x<<","<<uno.y<<","<<uno.z<<")"<<", "<<uno.carica;
			return s;
		};
};

class insieme_cariche{
	private:
		vector<carica_elettrica> cariche;
	public:
		insieme_cariche();
		void aggiungi(double x0,double y0, double z0, double carica1){
			cariche.push_back({x0,y0,z0,carica1});
		};
		double potenziale_tot(double xp,double yp, double zp){
			double vtot=0;
			
			
			for(auto a: cariche){
				double raggio= sqrt(
						pow(xp-a.x,2) + pow(yp-a.y,2) + pow(zp-a.z,2)
					);
				vtot=vtot +	(	(1/(4*pi*epsilon))* (a.carica/raggio)	);
			}
			return vtot;
		};
	
};

int main(){
	carica_elettrica uno={1,0,0,3};
	carica_elettrica due={0,1,0,3};
	carica_elettrica tre={0,0,1,3};
	vector<insieme_cariche> insieme1;
	
	
	
}
