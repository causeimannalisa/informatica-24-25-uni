#include <iostream>
#include <cmath>
#include <vector>
#include <random>

using namespace std;

//classe che rappresenta un robot
//	coord x e y, theta rispetto a asse x, stato motore(on/off)
//	 costruttore: robot a (0,0) e tutto off
//	



struct punto{
	double x;
	double y;
};

class robottino{
	private:
		punto loc;
		double theta;
		bool motore;
		
	public:
		robottino(){
			loc={0,0};
			theta=0;
			motore=false;
		};
		robottino(punto loc0, double angolo, bool motorino){
			loc=loc0;
			theta=angolo;
			motore=motorino;
		};
		
		void stato(){
			cout<<"("<<loc.x<<","<<loc.y<<")"<<endl;
			
		};
		void destra(double dtheta){
			
		};
		void sinistra(double dtheta){};
		void avanza(double d){ }; //if motore is true, verso theta
		void accendi(){
			motore=true;
		};
		void spegni(){
			motore=false;
		};
		double distanza_percorsa(){
			//return distanza percorsa in metri
		};
};

int main(){
	
}
