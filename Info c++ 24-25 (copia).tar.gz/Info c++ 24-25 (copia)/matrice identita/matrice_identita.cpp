#include <iostream>
#include <cmath>

using namespace std;

//riempi una matrice quadrata con una identita

int main(){
	constexpr int n=6;
	int matrice[n][n];
	
	int i=0;
	int j=0;
	while(i<n){
		j=0;
		while(j<n){
			if(i==j){
				matrice[i][j]=1;
			}
			else{
				matrice[i][j]=0;
			}
			cout<<matrice[i][j]<<" ";
			
			if((j+1)%n==0){
				cout<<endl;
			}
			
			j++;
		}
		i++;
	}
	
	
}
