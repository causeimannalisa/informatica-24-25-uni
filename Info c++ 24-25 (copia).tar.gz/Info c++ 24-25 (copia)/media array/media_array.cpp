#include <iostream>
#include <cmath>

using namespace std;

//prendi array e calcola media elementi e stampa quelli maggiori

int main(){
			//per creare una costante tipo indice array uso " constexpr " 
	int n;
	cout<<"n: "<<endl;
	cin>>n;
	
	double hello[n];
	cout<<"inserisci n numeri reali: "<<endl;
	int i=0;
	double somma=0;
	while(i<n){
		cin>>hello[i];
		//		cout<<hello[i]<<endl;
		somma=somma+hello[i];
		i++;
	}
	
	double media=somma/n;
	cout<<"la media del tuo array è: "<<media<<endl;
	
	//elementi maggiori della media
	
	i=0;
	int j=0;
	cout<<"numeri maggiori della media: ";
	while(i<n){
		if(hello[i]>media){
			cout<<hello[i]<<" ";
			
			j++;
		}
		i++;	
	}
	cout<<endl<<"numeri di elementi maggiori della media: "<<j<<endl;
	
}
