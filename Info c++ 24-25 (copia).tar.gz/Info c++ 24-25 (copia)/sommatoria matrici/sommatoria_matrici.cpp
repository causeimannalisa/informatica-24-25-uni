#include <iostream>
#include <cmath>

using namespace std;

//leggi due matrici A B di MxN reali e calcola:		sqrt(somma(pow(A-B,2)))

int main(){
	constexpr int m=3;
	constexpr int n=4;
	
	double a[m][n];
	double b[m][n];
	
	cout<<"inserisci la matrice a"<<endl;
	int i=0;
	int j=0;
	while(i<m){
		j=0;
		while(j<n){
			cin>>a[i][j];
			j++;
		}
		i++;
	}
	cout<<"inserisci la matrice b"<<endl;
	i=0;
	j=0;
	while(i<m){
		j=0;
		while(j<n){
			cin>>b[i][j];
			j++;
		}
		i++;
	}
	
	i=0;
	
	double righe=0;
	
	while(i<m){
		j=0;
		while(j<n){
			righe=righe + (pow(	a[i][j]-b[i][j]	,2));
			j++;
		}
		i++;
	}
	
	double tot=sqrt(righe);
	
	cout<<tot<<endl;
	
	
	
}
