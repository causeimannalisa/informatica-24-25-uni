#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

//classe per frazioni
//	numeratore e denominatore
//	 2/3 costruttori, 4 operazioni + operatore << per stampare


class frazione{
	public:
		double numeratore;
		double denominatore;
		
	private:
		frazione(){
			numeratore=0;
			denominatore=1;
		};
		frazione(double num, double den){
			numeratore=num;
			denominatore=den;
		};
		void semplificazione(double n, double d){
			//mettici massimo comune divisore e dividili, poi stampali
		}
		void somma(frazione &uno){
			double somma_n=numeratore*uno.denominatore + denominatore*uno.numeratore;
			double somma_d=denominatore*uno.denominatore;
			semplificazione(somma_n,somma_d);
			//non stampare qua, basta richiamare semplifica e poi stampa da lui
		};
		void sottrazione(frazione &uno){
			//fai come per somma
		};
		void moltiplicazione(frazione &uno){
			//idem
		};
		void divisione(frazione &uno){
			//idem
		};
};

int main(){
	
}
