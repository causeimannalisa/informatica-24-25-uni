#include <iostream>
#include <cmath>

using namespace std;

// scrivi un programma che stampa i primi n termini di fibonacci con n<100
// 		i primi 2 valori=1, il resto x[i]=x[i-1]+x[i-2]

int main(){
	int n;
	cin>>n;
	if(n<=100){
			
		long double x[n];
		x[0]=1; 
		x[1]=1;
		int i=2;
		while(i<n){
			x[i]=x[i-1]+x[i-2];
			i++;
			
		}
		i=0;
		while(i<n){
			cout<<x[i]<<", ";
			i++;
		}
			
	}
	else{
		cout<<"vuoi farlo esplodere sto computer?"<<endl;
	}
	
}
