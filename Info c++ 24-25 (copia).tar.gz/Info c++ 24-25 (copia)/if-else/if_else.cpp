#include <iostream>
using namespace std;

int main(){
	int numero;
	cout<<"inseisci numero a scelta"<<endl;
	cin>>numero;
	
	if(numero>=0){
		cout<<"Il numero è maggiore o uguale a zero"<<endl;
	}
	else{
		cout<<"Il numero è negativo"<<endl;
	}
	
	
	int boh;
	cout<<"inseisci numero a scelta"<<endl;
	cin>>boh;
	
	if(boh%2==0){
		cout<<"Il numero è pari"<<endl;
	}
	else{
		cout<<"Il numero è dispari"<<endl;
	}
}
