#include <iostream>
#include <cmath>
#include <vector>
#include <map>

using namespace std;

// classe che definisce un polinomio con var x
//	public: costruttore senza par
//	costr con parametri che crea il polinomio cx^n (double c, int n)
//	aggiungi.monomio(double c, int n) per aggiungere al poli il monomio cx^n
//	grado--> restituisce il grado del poli
//	visualizza()--> scrive il polinomio
//	valuta(double z), valuta il polinomio in un punto z

//map.end()->first mappa con key in ordine crescente, voglio prendere l ultima, ovvero la maggiore
class polinomio {
	private:
		map<int,double,greater<int>>monomio;
		
	public:
		polinomio(){
			
		};
		polinomio(map<int,double,greater<int>> monomio0,double c, int n){
			monomio=monomio0;
		};
		
		void aggiungi_monomio(double c, int n){
			monomio[n]= monomio[n]+c;
		};
		
		int grado(){
			return monomio.begin()->first;
		};
		
		void visualizza(){
			for(auto x:monomio){
				if(x.second!=0){
					if(x.second>0){cout<<"+";}
					else{cout<<"-";}
					cout<<" "<<x.second<<"x^"<<x.first<<" ";
				}
			}
			cout<<endl;
		};
		
		double valuta(double z){
			double tot=0;
			for(auto x:monomio){
				tot=tot+ (x.second*pow(z,x.first));
			}
			return tot;
		};
		
};



int main(){
	polinomio uno;
	
	double c;
	int n;
	int times;
	bool flag;
	cout<<"vuoi aggiungere monomi?"<<endl;
	cin>>flag;
	if(flag==true){
		cout<<"quanti?"<<endl;
		cin>>times;
	
		int i=0;
		cout<<"inserisci c e n:"<<endl;
		while(i<times){
			
			cin>>c>>n;
			uno.aggiungi_monomio(c,n);
			i++;
		}
	}
	//cout<<"lol?";
	//string lol;
	//cin>>lol;
	
	//if(lol=="#"){
		cout<<"grado polinomio inserito: "<<uno.grado()<<endl;
		uno.visualizza();
		
		double z;
		cout<<"in quale punto vuoi valutare il polinomio?"<<endl;
		cin>>z;
		cout<<"polinomio in z="<<z<<": "<<uno.valuta(z)<<endl;
		
	//}

}
