#include <iostream>
#include <cmath>

using namespace std;

//array reale, calcola media e varianza

int main(){
	
	int n;
	cout<<"n: "<<endl;
	cin>>n;
	
	double hello[n];
	cout<<"inserisci n numeri reali: "<<endl;
	int i=0;
	double somma=0;
	while(i<n){
		cin>>hello[i];
		//		cout<<hello[i]<<endl;
		somma=somma+hello[i];
		i++;
	}
	
	double media=somma/n;
	cout<<"la media del tuo array è: "<<media<<endl;
	
	double varianza;
	i=0;
	while(i<n){
		varianza=varianza + pow((hello[i]-media),2);
		i++;
	}
	varianza=varianza/n;
	cout<<"La varianza è: "<<varianza<<endl;
}
