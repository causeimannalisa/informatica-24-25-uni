#include <iostream>
#include <cmath>
#include <vector>
#include <random>

using namespace std;

//scrivi un giochino in cui devi indovinare dove sta ul tesoro in una griglia NxN
//	all inizio ti trovi su (0,0).
//	ad ogni istante mi stampa la distanza tra me e il tesoro (x1-xme),(y1-yme)
//	posso spostarmi a croce
//	 termina dopo tot passi o quando trova il tesoro

mt19937 generatore;

 

int main(){
	int seme=time(0);
	generatore.seed(seme);
	
	
	
	cout<<"welcome a questa caccia al tesoro!!"<<endl;
	
	int ncelle;
	cout<<"quante celle vuoi NxN?"<<endl;
	cin>>ncelle;
	
	int npassaggi;
	cout<<"quanti passaggi vuoi usare al massimo per trovare il tuo tesoro? ";
	cin>>npassaggi;
	
	uniform_int_distribution<int> randomcoords(0,(ncelle-1));
	int xt=randomcoords(generatore);
	int yt=randomcoords(generatore);
	
	
	int xme=0;
	int yme=0;
	
	cout<<"coord del tesoro scelte, te inizierai a (0,0)"<<endl;
	cout<<"per ogni mossa potrai spostarti di uno: sopra, sotto, avanti o dietro"<<endl;
	
	string mossa;
	int i=1;
	while((xme!=xt && yme!=yt) || i<npassaggi){
		cin>>mossa;
		if(mossa=="sopra"){
			if(yme<ncelle){yme++;}
			else{cout<<"resti fermo"<<endl;}
		}
		else if(mossa=="sotto"){
			if(yme>0){yme--;}
			else{cout<<"resti fermo"<<endl;}
		}
		else if(mossa=="avanti"){
			if(xme<ncelle){xme++;}
			else{cout<<"resti fermo"<<endl;}
		}
		else if(mossa=="dietro"){
			if(xme>0){xme--;}
			else{cout<<"resti fermo"<<endl;}
		}
		else{
			cout<<"qualcosa è andato storto, riprova"<<endl;
		}
		cout<<"("<<xme<<","<<yme<<")"<<endl;
		i++;
	}
	if(xme==xt && yme==yt){
		cout<<"congrats!! hai vinto"<<endl;
	}
	else{
		cout<<"hai comunque perso -_-"<<endl;
	}
	
}
