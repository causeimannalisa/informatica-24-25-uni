#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>

using namespace std;

//dato vendite.txt: prezzo	-	n_vendite
//		leggi i dati e scrivi la spesa totale

int main(){
	fstream dato;
	dato.open("vendite.txt",ios::in);
	if(!dato.is_open()){
		cerr<<"c'è stato un errore, riprovare";
		exit(1);
	}
	double tot=0;
	double costo, vendite;
	
	while(!dato.eof()){
		dato>>costo>>vendite>>ws;
		
		tot=tot+ (costo*vendite);
	}
	dato.close();
	
	cout<<"ecco il ricavato totale: "<< tot;
}
