#include <iostream>
#include <cmath>

using namespace std;

//inserire una matrice reale MxN e che calcola in un array tutto le somme di ogni riga in una array

int main(){
	constexpr int m=3;
	constexpr int n=4;
	
	double matrice[m][n];
	
	cout<<"inserisci valori matrice"<<endl;
	int i=0;
	int j;
	double somma[m];
	while(i<m){
		j=0;
		while(j<n){
			cin>>matrice[i][j];
			
			cout<<matrice[i][j]<<" ";
			
			if((j+1)%n==0){
				cout<<endl;
			}
			somma[i]=somma[i]+matrice[i][j];
			
			j++;
		}
		i++;
	}
	
	for(double a: somma){
		cout<< a <<endl;
	}
	
}
