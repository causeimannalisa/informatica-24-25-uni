#include <iostream>
#include <cmath>
#include <vector>
#include <map>
using namespace std;

//numero di volte che una parola viene ripetuta nel testo con map e vector

map<string,int> ripetizione(vector<string> &testo){
	map<string,int> rip;
	for (string parola:testo){
		rip[parola] += 1;
	}
	return rip;
}

int main(){
	vector <string> testo;
	cout<<"inserisci testo (input ## to end):"<<endl;
	string x;
	while(x!="##"){
		cin>>x;
		testo.push_back(x);
	}
	
	map<string,int> rippe=ripetizione(testo);
	for (auto y: rippe){
			cout<<"parola: "<< y.first<<", valore: "<< y.second << endl;
	}
	
}
