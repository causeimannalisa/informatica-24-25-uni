#include <iostream>
#include <cmath>

using namespace std;

//due array int n
//		stampa numero di elementi a==b

constexpr int n=5;
int idcrisis(int aa[n],int bb[n]){
	int i=0;
	int j=0;
	int tot=0;
	while(i<n){
		j=0;
		while(j<n){
			if(aa[i]	==	bb[j]){
				tot=tot+1;
			}
			j++;
		}
		i++;
	}
	return tot;
}

//int mainnn

int main(){
	int a[n],b[n];
	
	cout<<"inserisci l'array: "<<endl;

	int k=0;
	while(k<n){
		cin>>a[k];
		k++;
	}
	cout<<"inserisci l'array: "<<endl;
	k=0;
	while(k<n){
		cin>>b[k];
		k++;
	}
	
	int wow=idcrisis(a,b);
	
	cout<< "ecco: "<< wow <<endl;
}
