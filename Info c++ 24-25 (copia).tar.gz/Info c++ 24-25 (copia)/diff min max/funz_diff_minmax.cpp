#include <iostream>
#include <cmath>

using namespace std;

//array  N calcola diff tra min e max
//	stampa risultato

				//se voglio mettere sopra int main, posso dichiarare la funzione sopra e sotto il main la descrivo
				
constexpr int n=5;
double differenza(double numeri[n]){
	int i=1;
	double max=numeri[0],min=numeri[0];
	
	while(i<n){
		if(numeri[i]>max){
			max=numeri[i];
		}
		if(numeri[i]<min){
			min=numeri[i];
		}
		
		i++;
	}
	double tot=max-min;
	return tot;

}

int main(){
	double numero[n];
	cout<<"inserisci: "<<endl;
	int j=0;
	while(j<n){
		cin>>numero[j];
		j++;
	}
	double diff=differenza(numero);
	
	cout<< "ecco la tua differenza: "<< diff <<endl;
}
