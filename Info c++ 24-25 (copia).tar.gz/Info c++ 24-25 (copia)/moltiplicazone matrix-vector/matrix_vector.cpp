#include <iostream>
#include <cmath>

// #include "leggi_array.cpp" 		per includere una funzione in un altro file e poterla richiamare stile libreria

using namespace std;

//matrice a :n x n reale, due array (u,v)di n reali 
// array u contiene dati di vettore n-dimensionali 
// v= a*u

constexpr int n=3;

void vabbe(double a[n][n],double u[n],double v[n]){
	int i=0;
	int j=0;
	
	while(i<n){
		v[i]=0;
		j=0;
		while(j<n){
			v[i] = v[i] + ( a[i][j]* u[j]);
			j++;
		}
		cout<<v[i]<<" ";
		i++;
		
	}	
	
}

int main(){
	cout<<"Calcoliamo il prodotto tra una matrice e un vettore"<<endl<<endl;
	double uno[n][n];
	double uu[n];
	double vv[n];
	
	cout<<"inserisci la matrice: "<<endl;
	int k=0;
	int l=0;
	
	while(k<n){
		l=0;
		while(l<n){
			cin>>uno[k][l];
			l++;
		}
		k++;
	}
	cout<<"inserisci u: "<<endl;
	k=0;
	while(k<n){
		cin>>uu[k];
		k++;
	}
	
	vabbe(uno,uu,vv);

	
}
