#include <iostream>
#include <cmath>

using namespace std;

//calcola traccia matrice quadrata --> somma diagonale

int main(){
	
	constexpr  int n=3;
	double matrice[n][n];
	
	cout<<"inserisci matrice 3x3: "<<endl;
	int i=0;
	int j=0;
	while(i<n){
		j=0;
		while(j<n){
			cin>>matrice[i][j];
			j++;
		}
		i++;
	}
	
	
	i=0;
	double traccia=0;
	while(i<n){
		traccia += matrice[i][i];
		i++;
	}
	cout<<"la tua traccia è: "<<traccia<<endl;
}
