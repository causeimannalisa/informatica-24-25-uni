#include <iostream>
#include <cmath>

using namespace std;

	// due array reali : calcola media pesata: somma xw/ somma w

int main(){

	int n;
	cout<<"n: "<<endl;
	cin>>n;
	
	double x[n];
	double w[n];
	
	cout<<"inserisci n numeri reali per w: "<<endl;
	int i=0;
	double sommaw=0;
	while(i<n){
		cin>>w[i];
		sommaw=sommaw+w[i];
		i++;
	}
	
	cout<<"inserisci n numeri reali: "<<endl;
	i=0;
	double sommax=0;
	while(i<n){
		cin>>x[i];
		sommax=sommax+(x[i]*w[i]);
		i++;
	}
	
	double mediap= sommax/sommaw;
	
	cout<<mediap<<endl;
	
}
