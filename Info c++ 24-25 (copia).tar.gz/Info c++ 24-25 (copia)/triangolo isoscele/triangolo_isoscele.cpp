#include <iostream>
#include <cmath>

using namespace std;

int main(){
	
	double a,b,c; //lati
	cout<<"Inserisci i tuoi lati"<<endl;
	cin>>a>>b>>c;
	cout<<"Ecco i tuoi lati: "<<a<<","<<b<<","<<c<<endl;
	
	string tipo="";
	
	if (((a+b)<=c)	&&	((a+c)<=b)	&&	((b+c)<=a)	&&	a<=0 && b<=0 && c<=0){
			cout<<"ERROR, sei sicuro sia un triangolo?"<<endl;
	}
	else{
		
		//INIZIO LATI
		
		if(a==b && b==c){
			tipo="equilatero";
		}
		else if (	(a==b) && (c!=b)	){
			tipo="isoscele";
		}
		else if(	(a!=b) && (b!=c)	){
			tipo="scaleno";
		}
		else{
			cout<<"C'è stato un errore, riprovare"<<endl;
			}
		cout<<"Il tuo triangolo è: "<<tipo<<endl;
		
		//INIZIO ANGOLI
		
		if(tipo=="isoscele" || tipo=="scaleno"){
			
			double uno=0, due=0;
			
			if(a>b && a>c){
				
				uno=a*a;
				due=b*b + c*c;
				
			}
			else if(b>a && b>c){
				uno=b*b;
				due=a*a+c*c;
			}
			else if(c>a && c>b){
				uno=c*c;
				due=b*b+a*a;
			}
			else{
				cout<<"errore if uno-due"<<endl;
			}
		
		
			if(uno==due){
				cout<<"E' un triangolo rettangolo"<<endl;
			}
		}
		
	}
	
	
	
	
}

//
//
