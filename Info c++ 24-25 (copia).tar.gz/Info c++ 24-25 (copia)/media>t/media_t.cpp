#include <iostream>
#include <cmath>

using namespace std;

//array N reali, t reale. media elementi>t. se nessuno maggiore media=0;

constexpr int n=5;

double mediat(double v[n],double t){
	int i=0;
	double tot=0;
	int j=0;
	
	while(i<n){
		if(v[i]>t){
			tot=tot+v[i];
			j++;
		}
		i++;
	}
	if(j>0){
		double med=tot/j;
		return med;
	}
	else{
		return tot;
	}
	
}

int main(){
	cout<<"Calcoliamo la media di numeri di un array maggiori di t"<<endl<<endl;
	double due[n];
	double tt;
	cout<<"inserisci l'array: "<<endl;
	int k=0;
	while(k<n){
		cin>>due[k];
		k++;
	}
	cout<<"inserisci t: "<<endl;
	cin>>tt;
	
	cout<< "ecco la tua media: "<< mediat(due,tt)<<endl;
	
}
