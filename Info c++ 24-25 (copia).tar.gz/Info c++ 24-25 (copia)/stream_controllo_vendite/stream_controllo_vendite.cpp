#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>

using namespace std;

// leggi vendite.txt e scrivi su vendite2.txt uali superano certi parametri dati dall utente
//		

int main(){
	double sup=0, wow=0;
	int ris;
	cout<<"inserisci parametri di filtro per prezzo o vendite"<<endl
	<<"premere:"<<endl<<"1- prezzo"<<endl<<"2- quantita vendute"<<endl;
	cin>>ris;
	cout<<"inserisci valore desiderato: "<<endl;
	if(ris==1){
		cin>>sup;
	}
	else if(ris==2){
		cin>>wow;
	}
	else{
			cerr<<"riprovare"<<endl;
	}
	
	fstream uno;
	fstream due;
	uno.open("/home/ac040083/Info c++ 24-25/stream_spesa/vendite.txt",ios::in);
	due.open("vendite2.txt",ios::out);
	if(!uno.is_open()){
		cerr<<"c'è stato un errore, riprovare";
		exit(1);
	}
	if(!due.is_open()){
		cerr<<"c'è stato un errore, riprovare";
		exit(1);
	}
	
	double costo, vendite;
	
	while(!uno.eof()){
		uno>>costo>>vendite>>ws;
		
		if(costo>=sup && vendite>=wow){
			due<<costo<<" "<<vendite<<endl;
		}
	}
	uno.close();
	due.close();
	
	
}
