#include <iostream>
#include <cmath>

using namespace std;

// data n, scrivi sen e cos di tutti gli angoli fino a 90 con passo i*90/n
	
int main(){
	int n;
	cout<<"n: "<<endl;
	cin>>n;
	
	int i=0;
	double angolo;
	
	while(i<=n){
		cout<<"angolo	"<<"sin	      "<<"cos	"<<endl;	//per fare le tabelle ginisco la row con \t
		
		while((i*90/n)<=90){
			double boh=i*90/n;
			
			angolo=boh/180*M_PI;
			
			double seno=sin(angolo);
			double coseno=cos(angolo);
			
			
			cout<< boh <<"\t"<<seno<<"\t"<<coseno<<"\t"<<endl;
			
			i++;	
		}
		cout<<""<<""<<""<<endl;
	}
	
}
	

