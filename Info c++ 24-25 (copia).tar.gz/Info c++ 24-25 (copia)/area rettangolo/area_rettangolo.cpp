#include <iostream>

using namespace std;

int main(){
	double b,h; //dichiarazione variabili--> inserisci data type
	double area, perimetro;
		// double= num reali a doppia precisione (guarda teoria conversione binaria)
		
	cout<<"Inserisci la base ";
	cin >> b;
	cout<<"inserisci l'altezza ";
	cin >> h; //cin come cout--> see in--> tipo prompt
	
	area=b*h;
	perimetro=2*(b+h);
	
	cout <<"L'area è: "<< area << endl
		<< "Il perimetro è: "<< perimetro<< endl;

}
		//non usare nomi variabili con numeri all inizio es: 6lol NO, lol6 YES
