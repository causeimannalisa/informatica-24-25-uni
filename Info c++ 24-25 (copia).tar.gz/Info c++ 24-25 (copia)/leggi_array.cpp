#include <iostream>
#include <cmath>

using namespace std;

//leggi array

void leggi(double x[n]){
	cout<<"inserisci l'array: "<<endl;
	int i=0;
	while(i<n){
		cin>>x[i];
		i++;
	}
}
