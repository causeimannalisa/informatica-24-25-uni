#include <iostream>
#include <cmath>

using namespace std;

//scrivi array di num reali e ordinali col bubble sort

int main(){
	constexpr int n=5;
	double x[n];
	
	int i=0;
	cout<<"inserisci array"<<endl;
	while(i<n){
		cin>>x[i];
		i++;
	}
	i=0;
	int j=0;
	double a;
	while(i<n-1){
		while(j<(n-1-i)){
			if(	x[j]	>	x[j+1] ){
				a=x[j];
				x[j]=x[j+1];
				x[j+1]=a;
			}	
			
			j++;
		}
		i++;
	}
	
	/* i=0;
	while(i<n){
		cout<<x[i]<<" ";
		i++;
	}*/
	for (double y: x){
		cout<< y<< " ";
	}
}
