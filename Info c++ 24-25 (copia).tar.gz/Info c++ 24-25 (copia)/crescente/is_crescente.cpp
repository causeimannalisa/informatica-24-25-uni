#include <iostream>
#include <cmath>

using namespace std;

//return true se gli elementi dell aray sono ordinati crescente

constexpr int n=5;

bool crescente(double numeri[n]){
	int i=1;
	bool ordinati=true;
	
	while(i<n && ordinati==true){
		if(numeri[i]<numeri[i-1]){
			ordinati=false;
		}
		else{
			i++;
		}
	}
	return ordinati;
}

int main(){
	double numeri[n];
	cout<<"numeri[n]"<<endl;
	int j=0;
	while(j<n){
		cin>>numeri[j];
		j++;
	}
	
	cout<<"i numeri sono ordinati? ";
	
	if(crescente(numeri)==false){
		cout<<"no";
	}
	else{ cout << "si";}
	
}
