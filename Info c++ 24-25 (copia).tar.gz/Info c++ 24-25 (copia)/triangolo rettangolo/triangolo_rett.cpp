#include <iostream>
#include <cmath>

//triangolo rettangolo

using namespace std;

int main(){
	double cateto1, cateto2;
	cout<<"inserisci lunghezza primo cateto"<<endl;
	cin >>cateto1; // >> CON CIN NON <<
	cout<<"inserisci lunghezza secondo cateto"<<endl;
	cin>>cateto2;
	
	double ipotenusa;
	double area, perimetro;
	
	ipotenusa=sqrt(pow(cateto1,2)+pow(cateto2,2));
	
	area=(cateto1*cateto2)/2;
	perimetro=cateto1+cateto2+ipotenusa;
	
	cout<<"l'ipotenusa è: "<<ipotenusa <<endl
		<<"l'area è: "<<area<<endl
		<<"il perimetro è: "<<perimetro<<endl;
	
}
