#include <iostream>
#include <cmath>

using namespace std;

// n e k naturali, se 0<= k >=n , calcola: binomiale n su k


		
int main(){
	int n,k;
	cout<<"inserisci n e k"<<endl;
	cin>>n>>k;
	
	if(k>=0 && k<=n){
		
	//	fattoriale n
		int i=1;
		double nfatt=1;
		while(i<=n){
				nfatt=nfatt*i;
				i++;
		}
		
	//	fattoriale k
		i=1;
		double kfatt=1;
		while(i<=k){
			kfatt=kfatt*i;
			i++;
		}
		
	// fattoriale n-k
		i=1;
		double nkfatt=1;
		while(i<=(n-k)){
			nkfatt=nkfatt*i;
			i++;
		}
		
		double binomiale=nfatt/(kfatt*nkfatt);
		
		cout<<binomiale<<endl;
	}
	else{
		cout<<"ERRORRRRR, riprova"<<endl;
	}
}

void ciaociao(){
	int valori[3]={"n","k","(n-k)"}
	int j=1;
	int fattoriale=1;
		//FINISCII
}

