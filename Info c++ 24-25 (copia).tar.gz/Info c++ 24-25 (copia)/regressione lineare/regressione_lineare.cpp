#include <iostream>
#include <cmath>

using namespace std;

// due array reali: calcola valori retta di regressione

int main(){
	
	int n;
	cout<<"n: "<<endl;
	cin>>n;
	
	double x[n];
	double y[n];
	
	int i=0;
	double sommax=0;
	double sommax2=0;
	
	cout<<"x"<<endl;
	while(i<n){
		cin>>x[i];
		sommax += x[i];
		sommax2 += pow(x[i],2);
		i++;
	}
	
	i=0;
	double sommay=0;
	
	cout<<"y"<<endl;
	while(i<n){
		cin>>y[i];
		sommay +=y[i];
		i++;
	}
	
	double sommaxy;
	
	i=0;
	while(i<n){
		sommaxy += x[i]*y[i];
		i++;
	}
	
	
	double a;
	double b;
	double delta;
	
	delta=(n*sommax2)- pow(sommax,2);
	
	a=((sommax2 * sommay)-(sommax * sommaxy))/delta;
	
	b=((n*sommaxy)-(sommax * sommay))/delta;
	
	cout<<"retta di tipo: a+bx"<<endl;
	cout<<"a: "<<a<<endl<<"b: "<<b<<endl;
	
	
	
}

/*
void ciao(){
	
	constexpr n=5;
	
	double w[n];
	double z[n];
	
	cout <<"w,z a coppie"<<endl;
	int j=0;
	while(j<n){
		cin>>w[j]>>z[j];
		j++;
	}
}
*/


