#include <iostream>
#include <cmath>

using namespace std;

//trasforma da binario in array a numero in base 10

int main(){
	
	constexpr int n=8;
	int numero[n];
	
	cout<<"inserisci le cifre binarie, thank u : "<<endl;
	int i=0;
	while(i<n){
		cin>>numero[i];
		i++;
	}
	
	
	int j=n-1;
	i=0;
	int totale=0;
	
	while(j>=0){
		if(numero[i]==1){
			totale+= numero[i]* pow(2, j);
		}
		// FUNZIONA ANCHE SENZA IF
		j--;
		i++;
	}
	cout <<"il tuo numero in base-10 è: "<< totale<<endl;
	
}
