#include <iostream>
#include <cmath>
using namespace std;

	//dato un punto calcola se interno, esterno o sulla circonferenza

int main(){
	
	double x,y;
	cout<<"punto: "<<endl;
	cin>>x>>y;
	
	double a,b,c;
	cout<<"inserisci a,b,c di una retta con questa forma: "<<endl<<"x^2 + y^2 + ax + by + c = 0"<<endl;
	cin>>a>>b>>c;
	
	
	
}
2
