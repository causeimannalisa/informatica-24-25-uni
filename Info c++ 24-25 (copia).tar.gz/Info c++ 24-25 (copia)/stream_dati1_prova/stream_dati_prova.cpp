#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#include <cstdlib>

using namespace std;

//leggi i contenuti double di un altro file (es txt or csv) 
//		calcola: media, deviazione , max e min 
//		can i solve it without saving data into a variable?

int main(){
	fstream dato;
	dato.open("valori_prova.txt",ios::in);
	if(!dato.is_open()){
		cerr<<"c'è stato un errore, riprovare";
		exit(1);
	}
	double media=0, somma=0, max=pow(2,-100), min=pow(2,100);
	int i=0;
	double x;
	while(!dato.eof()){
	
		dato>> x >>ws;
		
			//media
		media=media+ x;
		
		somma= somma + x*x;
		
			//min
		if(x<min){
			min=x;
		}
			//max
		if(x>max){
			max=x;
		}
		i++;
	}
	media=media/i;
		//deviazione
	double deviazione=sqrt((somma/i )- media*media);
	
	
	cout<<"media: "<<media<<endl
		<<"deviazione: "<<deviazione<<endl
		<<"minimo: "<< min <<endl
		<<"massimo: "<< max <<endl;
	
}
