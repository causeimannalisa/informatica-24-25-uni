#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

//n reale, return un vector con tutti i divisori di n

vector<int> divisori(int n){
	vector<int>divisore;
	int i=0;
	while(i<=sqrt(divisore.size())){
		if(n%i==0){
			divisore.push_back(i);
		}
		i++;
	}
	
	return divisore;
}

int main(){
	int numero;
	cout<<"inserisci n"<<endl;
	cin>>numero;
	
	vector<int> due=divisori(numero);
	int i=0;
	while(i<due.size()){
		cout<<due[i]<<" ";
		i++; 
	}
}
