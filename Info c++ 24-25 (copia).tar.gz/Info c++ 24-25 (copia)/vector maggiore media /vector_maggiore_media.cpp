#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

// funzione con vector reale v e parametro reale t
//	return un vector reale con gli elementi di v tali che :	 v > t*m	m=media di v

vector <double> maggiore(vector<double> &v, double t){
	vector <double> totale;
	
	int i=0;
	double media=0;
	int n=v.size();
	
	while(i<n){
		media= media + v[i];
		i++;
	}
	media=media/n;
	
	i=0;
	while(i<n){
		if(v[i]>(media*t)){
			totale.push_back(v[i]);
		}
		i++;
	}
	return totale;
}

int main(){
	vector<double>uno;
	int m;
	
	cout<<"quanti dati vuoi inserire?"<<endl;
	cin>>m;
	
	uno.resize(m);
	
	cout<<"inserisci valori del vettore"<<endl;
	int j=0;
	while(j<m){
		cin>>uno[j];
		j++;
	}
	
	double tt;
	cout<<"quanto vale t?"<<endl;
	cin>>tt;
	
	vector<double> risultato=maggiore(uno,tt);
	int boh=risultato.size();
	
	j=0;
	while(j<boh){
		cout<<risultato[j]<<" ";
		j++;
	}
}
