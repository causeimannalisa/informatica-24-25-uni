#include <iostream>
#include <cmath>
#include <vector>
#include <list>
#include <random>

using namespace std;

//

class circonferenza{
	private:
		double xc;
		double yc;
		double raggio;
		double vx;
		double vy;
		
		
	public:
		circonferenza(double uno,double due,double tre,double quattro,double cinque){
			xc=uno;
			yc=due;
			raggio=tre;
			vx=quattro;
			vy=cinque;
			
		};
		void visualizza(){
			cout<<"("<<xc<<","<<yc<<"), r: "<<raggio<<endl
			<<"vel x: "<<vx<<endl<<"vel y: "<<vy<<endl;
		};
		void sposta(double dt){
			double dx=vx*dt;
			double dy=vy*dt;
			
			xc=xc+dx;
			yc=yc+dy;
			
		};

};

int main(){
	vector<circonferenza> cerchi={
			{0,0,5,1,2},
			{1,0,3,2,4},
			{2,0,1,4,8}
		};
	
	for (auto x:cerchi){
		x.visualizza();
		x.sposta(5);
		cout<<"centro dopo 5 unita di tempo: ";
		x.visualizza();
	}
	
}
