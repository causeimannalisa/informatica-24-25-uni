#include <iostream>
#include <cmath>

using namespace std;

//scrivi funz con parametro un array "dati" di N num reali, con N constexpr
		//calcola varianza 
		// stampa tutto

constexpr int N=5;
double uno(double dati[N]){
	double tot=0;
	int i=0;
	while(i<N){
		tot=tot+dati[i];
		i++;
	}
	
	double media= tot/N;
	double varianza=0;
	
	i=0;
	while(i<N){
		varianza=varianza +(1/N)*(pow((dati[i]-media),2));
		i++;
	}
	return varianza;

}


int main(){
	
	double dati1[N];
	int j=0;
	while(j<N){
		cin>>dati1[j];
		j++;
	}
	
	
	
	
}
