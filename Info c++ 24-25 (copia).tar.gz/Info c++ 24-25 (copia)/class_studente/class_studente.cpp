#include <iostream>
#include <cmath>
#include <vector>
#include <list>
#include <random>

using namespace std;

// scrivi classe con dati studente 
//	 matricola, nome, cognome, data, luogo nascita, esami sostenuti(corso,data,voto) (++)
// definire i seguenti metodi:
//		costruttore
//		mostra_dati(), scrive i dati anagrafici
//		elenco_esami(), scrive i dati degli esami

struct data_varia{
	int giorno,mese,anno;
};
struct esame{
	string corso;
	data_varia data_esame;
	int voto;
};

class studente{
	private:
		string matricola;
		string nome;
		string cognome;
		data_varia data;
		string luogo_na;
		vector<esame> esami;
		
		
	public:
		studente(string mat,string nom,string cogn, data_varia data_nascita,string luogo, vector<esame> e){
			matricola=mat;
			nome=nom;
			cognome=cogn;
			data=data_nascita;
			luogo_na=luogo;
			esami=e;
		};
		void mostra_dati(){
			cout<<"nome: "<<nome<<endl
				<<"cognome: "<<cognome<<endl
				<<"nascita: "<<luogo_na<<", "<<data.giorno<<"/"<<data.mese<<"/"<<data.anno
				<<endl;
			
		};
		void elenco_esami(){
			for(auto x: esami){
				cout<<"corso: "<<x.corso<<",  data esame: "<<x.data_esame.giorno<<"/"<<x.data_esame.mese<<"/"<<x.data_esame.anno
				<<",  votazione: "<<x.voto<<";"<<endl;
			}
			
		};
		void aggiungi_esame(string corso, data_varia data, int voto){
			esame uno={corso,data,voto};
			esami.push_back(uno);
		};
};

int main(){
	
	studente prova = {	"111111",
						"annalisa",
						"cristallini",
						{19,7,2004},
						"marsciano",
						{
							{"barzellette",{22,5,2021},31},
							{"battute",{15,12,25},23}
						}
					};


}
