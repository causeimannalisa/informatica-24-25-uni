#include <iostream>
#include <cmath>

using namespace std;

//	dati x e n calcola : e^x con serie di taylor, per i primi n termini
//		confronta con il valore ricevuto per exp(x)

int main(){
	
	double x;
	int n;
	
	cout<<"X e N"<<endl;
	cin>>x>>n;
	
	double somma=1;
	int i=1;

	while(i<n){
		int j=1;
		double fattoriale=1;
		
		while(j<=i){
			fattoriale=fattoriale*j;
			j++;
		}
		somma=somma +(	(pow(x,i))/fattoriale	);
		i++;
	}
	
	
	double funzione=exp(x);
	
	cout<<"il tuo e^x è: "<<somma<<endl<<"quello da funzione è: "<<funzione<<endl;
	
	
}
