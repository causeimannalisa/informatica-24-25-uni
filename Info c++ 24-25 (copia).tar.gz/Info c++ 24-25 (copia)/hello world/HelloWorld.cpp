#include <iostream> //only a few, dont need ;

	//compila prima di eseguire
	
using namespace std;

int main(){
	cout << "Hello World!" << endl;
		//cout= see out per stampare(?),<<= scrivi a sinistra, endl= end line.manda a capo
		
	cout << "How to get away with murder" << endl
		<<"psych" << endl
		<<"why why whyyyy"<< endl
		<<"ease my mind"<< endl;
		// << a dividere stringhe e funzioni
			// ; solo a fine serie di comandi
}
