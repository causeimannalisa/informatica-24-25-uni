#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

//			VECTORS
// ha una dimensione che puo variare durante il programma

int main(){
	
	vector<int>a;
	cout<< a.size()<<endl;
	
	//gli aggiungo valori
		//devo per forza fare .push_back
				// fare a[0]=1 non funziona
	a.push_back(5);
	a.push_back(8);
	a.push_back(3);
	
	// prendo la size
	int n=a.size();
	cout<<"grandezza vettore: "<< n <<endl;
	
	//stampo
	int i=0;
	while(i<n){
		cout<<a[i]<<" ";
		i++;
	}
	
}
