#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

// vector reali, return media

double media(vector<double>dati){
	int i=0;
	double tot=0;
	while(i<dati.size()){
		tot= tot+ dati[i],
		i++;
	}
	double mediav=tot/dati.size();
	
	return mediav;
}

int main(){
	vector<double>uno;
	int n;
	
	cout<<"quanti dati vuoi inserire?"<<endl;
	cin>>n;
	
	uno.resize(n);
	
	cout<<"inserisci valori del vettore"<<endl;
	int j=0;
	while(j<n){
		cin>>uno[j];
		j++;
	}
	
	cout<<"ecco la media del tuo vettore: "<< media(uno);
}
