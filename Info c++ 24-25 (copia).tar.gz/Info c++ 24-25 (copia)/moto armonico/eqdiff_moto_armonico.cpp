#include <iostream>
#include <cmath>

using namespace std;

//risolvi eq diff oscillatore armonico : x'' + wx = 0
//		con x0,v0 approssimati usando il metodo di eulero
//		

		//da fare a casa--> fai su carta 


int main(){
	int n;
	double tmax, w;
	
	cout<<"inserisci n, tmax,w: "<<endl;
	cin>>n>>tmax>>w;
	
	double t=tmax/n;
	
	int N=n+1;
	double x[N],v[N];
	
	cout<<"inserisci x(t=0) e v(t=0): "<<endl;
	cin>>x[0]>>v[0];
	
	int i=1;
	while(i<N){
		x[i]=x[i-1] +t*v[i-1];
		v[i]=v[i-1]-(w*w)*t*x[i-1];
		i++;
	}
	
	double t0=0;
	i=0;
	cout<<"ecco la tua soluzione:"<<endl;
	while(i<N){
		cout<<"t= "<<t0<<endl<<"x= "<< x[i]<< ", v= "<<v[i]<<endl;
		t=t+t;
		i++;
	}
}
