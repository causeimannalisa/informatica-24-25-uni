#include <iostream>
#include <cmath>

using namespace std;

//funz due array a: na, b:nb
//	 return 'true' se NON hanno elementi in comune, else 'false'

bool ciaociao(double a[], double b[], int na, int nb){
	int i=0;
	int j=0;
	
	bool boh=true;
	
	while(i<na and boh==true){
		j=0;
		while(j<nb){
			if(a[i]==b[j]){
				boh=false;
			}
			j++;
		}
		i++;
	}
	return boh;
}

int main(){
	int na, nb;
	cout<<"inserisci dimensione array: a,b"<<endl;
	cin>>na>>nb;
	
	double aa[na],bb[nb];
	cout<<"inserisci array "<<endl;
	int j=0;
	while(j<na){
		cin>>aa[j];
		j++;
	}
	cout<<"inserisci array "<<endl;
	j=0;
	while(j<nb){
		cin>>bb[j];
		j++;
	}
	
	cout<<"soluzione: "<<ciaociao(aa,bb,na,nb)<<endl;
		
}
