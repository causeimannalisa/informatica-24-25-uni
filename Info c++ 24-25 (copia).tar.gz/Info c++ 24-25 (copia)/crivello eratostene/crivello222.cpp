#include <iostream>
#include <cmath>

using namespace std;

// implementa il crivello di eratostene per trovare i numeri primi tra 2 e n, con n constexpr
//		usa un array x[] di n+1 valori bool con default true
//		per i: 2< i <n si guarda il valore di x[i]:
//			se false--> nada
//			se true--> scrivo i, metto =false tutti i x[j] con j multiplo di i		--> incrememnto i=i+i invece di j 

		//	n introdotto dal player

int main(){
	
	int y;
	cin>>y;
	bool primo = true;
	
	constexpr int n=1000;
	bool x[n+1];
	int a=0;
	while(a<n){
		x[a]=true;
		a++;
	}
	
	int i=2;
	while(i<=1000 && primo==true){
		if(x[i]==true){
			int j=i;
			while(j<=n){
				x[j]=false;
				j=j+i;
			}
		}
		else{
			if(i==y){
				primo=false;
				
			}
		}
		
		i++;
	}
	
	if(primo==false){
	cout<<"il tuo numero non è primo"<<endl;
	}
	else{
		cout<<"è un numero primo"<<endl;
	}
	
	k=2;
	while(k<n){
		if(x[k]==true){
			
		}
	}
	
	
}
