#include <iostream>
#include <cmath>

using namespace std;

// implementa il crivello di eratostene per trovare i numeri primi tra 2 e n, con n constexpr
//		usa un array x[] di n+1 valori bool con default true
//		per i: 2< i <n si guarda il valore di x[i]:
//			se false--> nada
//			se true--> scrivo i, metto =false tutti i x[j] con j multiplo di i		--> incrememnto i=i+i invece di j 
	// chiamasi anche sleeve

int main(){
	
	constexpr int n=1000;
	bool x[n+1];
	int a=0;
	while(a<n){
		x[a]=true;
		a++;
	}
	
	int i=2;
	int b=0;
	while(i<=n){
		if(x[i]==true){
			int j=2*i;
			while(j<=n){
				x[j]=false;
				j=j+i;
			}
			cout<<i<<", ";
			b++;
		}
		
		i++;
	}
	cout<<endl<<"il numero di elementi primi: "<<endl<<b<<endl;
	
}
