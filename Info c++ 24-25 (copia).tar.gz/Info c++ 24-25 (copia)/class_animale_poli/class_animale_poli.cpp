#include <iostream>
#include <vector>


using namespace std;

//creare class ANIMALE e almeno tre classi figlie con tipi di animali
//	campi: nome + 2 virtual methods : presentati, muoviti
//	 muoviti dipende dall animale (????)
//	 NEL MAIN 
//		vector di puntatori ad animali, pieno di oggetti specifici delle classi

//		fai funzione per creare un nuovo oggetto di una classe figlia chiedendo tutto all utente(anche tipo di animale)
//				riempici il vector
//				animale* crea_animale(){}

class animale{
	protected:
		string nome;
		
	public:
		animale();
		animale (nome0){
			nome=nome0
		};
		
		virtual string presentati();
		
		virtual string muoviti();
};

class cane: public animale{
	private:                                                                   
		string razza;
		double peso;
		
	public:
		cane():animale(){razza,peso};
		cane(string nome1, string razza0, double peso0):animale(nome0){
			nome1=nome;
			razza=razza0;
			peso0=peso;
		};
		string presentati(){
			string ciao;
		};
		string muoviti();
		
};


int main(){
	
}
