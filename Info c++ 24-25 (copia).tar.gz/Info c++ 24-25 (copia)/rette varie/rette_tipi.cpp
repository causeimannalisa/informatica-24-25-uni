#include <iostream>
using namespace std;

	//determina se le due rette sono coincidenti, parallele o intersecanti(calcola punto)

int main(){
	double m1,m2,q1,q2;
	
	cout<<"Data la forma y=mx+q, scrivi m e q di due rette"<<endl
		<<"Inserisci prima retta"<<endl;
	cin>>m1>>q1;
	
	cout<<"Inserisci seconda retta"<<endl;
	cin>>m2>>q2;
	
	string tipo="";
	
	if (m1==m2 && q1==q2){
		cout<<"coincidenti"<<endl;
	}
	else if(m1==m2 && q1!=q2){
		cout<<"parallele"<<endl;
	}
	else{
		cout<<"intersecanti"<<endl;
		double q3=q2-q1;
		if (q3==0){
			cout<<"qualcosa è andato storto, riprovare"<<endl;	
		}
		else{
			double x=(m1-m2)/(q3);
			double y=(m1*x)+q1;
			cout<<"Le coordinate sono: "<<endl<<"x: "<<x<<endl<<"y: "<<y<<endl;
		}                                                                                                                          
	}
	
	
	
}
