#include <iostream>
#include <cmath>

using namespace std;

//calcola integrale approssimato di una funzione su [a,b] sommando l area di n trapezi di altezza h=(b-a)/n
		//divido [a,b] in n intervalli uguali con 'altezza' il valore di f(x) : x1-x0= h
int main(){
	
	double a,b;
	int n;
	
	cout<<"scegli a e b estremi d'intervallo"<<endl;
	cin>>a>>b;
	
	cout<<"seleziona numeri di intervalli"<<endl;
	cin>>n;
	
	cout<<"calcoliamo l'integrale della funzione (x-2)^3 : "<<endl;
	
	double x[n];
	double y[n];
	double h=(b-a)/n;
	double area=0;
	
	int i=0;
	while(i<=n){
		x[i]=a+(i*h);
		//y[i]=pow((x[i]-2),3);
		y[i]=x[i]+1;
		if (i>0){
			area += ((y[i-1]+ y[i])*h)/2;
		}
	i++;
	}
	cout<<"il tuo integrale è: "<< area<<endl;
	
}
