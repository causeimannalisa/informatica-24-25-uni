#include <iostream>
#include <vector>
#include <random>

using namespace std;

//crea funzione  con due parametri reali mu e sigma (media e devizione) e un intero n
//	return: vector reale di num random distr normale

mt19937 generatore;

vector<double> numeri(double mu, double sigma, int n){
	vector <double> rand;
	
	normal_distribution<double> distr_norm(mu,sigma); // distribuzione
	
	int i=0;
	while (i<n){
		double x=distr_norm(generatore);
		rand.push_back(x);
		i++;
	}
	return rand;
}

int main(){
	int seme=time(0);
	generatore.seed(seme);
	
	vector<double> rand2;
	double muu, sigma2, n2;
	
	cout<<"inserisci media, varianza e size del vettore desiderato:"<<endl;
	cin>>muu>>sigma2>>n2;
	
	rand2=numeri(muu,sigma2,n2);
	
	int i=0;
	
	while(i<n2){
		cout<<rand2[i]<<" ";
		i++;
	}
	// calcola differenza tra varianza/media voluti e ottenuti, poi piangi
}
