#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

//

int main(){
	vector <int> a(5); //per dargli la dimensione: tra tonde
	
	int n=4;
	a.resize(n); 	//ridimensiona il vettore per avere una dim n
	
	//esempio
	vector <double> b;
	int m;
	cout<<"quanti elementi vuoi inserire"<<endl;
	cin>>m;
	b.resize(m);
	
	cout<<"inserisci elementi"<<endl;
	int i=0;
	while(i<m){
		cin>>b[i];
		i++;
	}
}
