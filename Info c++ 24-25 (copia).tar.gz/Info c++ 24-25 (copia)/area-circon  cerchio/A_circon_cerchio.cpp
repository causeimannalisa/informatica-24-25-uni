#include <iostream>
#include <cmath> //per funzioni math
//per compilare F9

using namespace std;

int main(){
	double raggio;
	cout<<"Inserisci raggio del cerchio: ";
	cin>>raggio;
	
	double area, circonferenza;
	
	area=M_PI*pow(raggio,2);
	circonferenza=2*M_PI*raggio;

	cout<<"L'area del tuo cerchio è: "<< area <<endl
		<<"La circonferenza misura: "<< circonferenza <<endl;
}
