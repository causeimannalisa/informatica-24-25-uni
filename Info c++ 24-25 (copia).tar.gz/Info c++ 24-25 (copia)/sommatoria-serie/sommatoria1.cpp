#include <iostream>
#include <cmath>

using namespace std;

//dati x reale e n naturale, calcola: 

int main(){
	
	double x;
	int n;
	cout<<"inserisci un numero reale e un intero"<<endl;
	cin>>x>>n;
	cout<<"x= "<<x<<endl<<"n= "<<n<<endl;
	
	double somma=0;
	int i=1;
	while(i<=n){
		somma=somma+ ((pow((-x),i))/i);
		i++;
	}
	cout<<"la tua somma è: "<< somma<<endl;
}
