#include <iostream>
#include <cmath>
#include <vector>
#include <list>
#include <set>

using namespace std;

//funzione con vector intero v
//	return un set di num interi che contiene gli elementi di v senza ripetizioni

set <int> ripetere(vector<int> v){
	set <int> norip;
	for(int x:v){
		norip.insert(x);
	}
	return norip;
}

int main(){
	int n;
	cout<<"inserisci dimensione vettore"<<endl;
	cin>>n;
	
	vector<int> v;
	v.resize(n);
	cout<<"inserisci vector"<<endl;
	int i=0;
	while(i<n){
		cin>>v[i];
		i++;
	}
	
	set<int>tot= ripetere(v);
	for (int y: tot){
		cout<< y<< " "; 
	}
}
