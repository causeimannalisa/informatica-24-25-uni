#include <iostream>
#include <cmath>
#include <vector>
#include <random>
#include <map>

using namespace std;

//funz che lancia n volte un dado bilanciato (1,6) e return: somma uscite

//funz che con la map trova la distribuzione empirica della somma dei dadi, richiamandola tot volte

mt19937 generatore;
//lancia n volte il dado
int sommadadi(int n){
	int somma=0;
	
	uniform_int_distribution<int> distr_uni(1,6);
	int i=0;
	while(i<n){
		int x =distr_uni(generatore);
		somma=somma+x;
		i++;
	}
	
	return somma;
	
}

//calcola quante volte escono le somme
map<int,int> uscite( int ndadi,int nsomme){
	
	map<int,int> sommetot;
	int i=0;
	while(i<nsomme){
		int x=sommadadi(ndadi);
		sommetot[x] += 1;
		i++;
	}
	
	return sommetot;
}

int main(){
	int seme=time(0);
	generatore.seed(seme);
	
	int ndadi;
	cout<<"inserisci numero di tiri del dado"<<endl;
	cin>>ndadi;
	
	int sommalanci=sommadadi(ndadi);
	cout<<"ecco la somma dei tuoi "<<ndadi<<" tiri: "<<sommalanci<<endl;
	

	int nfunz;
	cout<<"quante somme vuoi calcolare?"<<endl;
	cin>>nfunz;
	
	map<int,int> distr_somme=uscite(ndadi,nfunz);
	cout<<"ecco una distribuzione delle somme che escono lanciando piu volte il dado n volte: "<<endl;
	for(auto y:distr_somme){
		cout<<y.first<<"-->"<<y.second<<endl;
	}
	
}
