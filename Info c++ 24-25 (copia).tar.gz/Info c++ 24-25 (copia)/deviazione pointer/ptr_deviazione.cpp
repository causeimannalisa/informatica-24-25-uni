#include <iostream>
#include <cmath>

using namespace std;

// funz array reali n
//	calcola: media e deviazione standard
//		salvali in altri due parametri di tipo double passati per riferimento


void calcoli(double dato[], int n, double &media, double &deviazione){
	int i=0;
	double tot;
	while(i<n){
		tot= tot+ dato[i];
		i++;
	}
	media=tot/n;
	i=0;
	while(i<n){
		deviazione= deviazione+ sqrt(pow((dato[i]-media),2))/(n-1);
		i++;
	}
}

int main(){
	int n;
	cout<<"inserisci dimensione array: "<<endl;
	cin>>n;
	
	double med, dev;
	
	double dati[n];
	cout<<"inserisci array "<<endl;
	int j=0;
	while(j<n){
		cin>>dati[j];
		j++;
	}
	calcoli(dati, n, med, dev);
	cout<<med<<" "<<dev<<endl;
	
		
}
