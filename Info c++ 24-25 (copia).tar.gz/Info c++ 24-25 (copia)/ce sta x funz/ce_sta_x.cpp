#include <iostream>
#include <cmath>

using namespace std;

//function array n int e int x 
//		se ho un punto c==x, dico la posizione di x,se non c è -1
//			stampa

constexpr int n=5;
int posizione(int uno[n], int x){
	int i=0;
	bool trovato=false;
	while(i<n && trovato==false){
		if(uno[i]==x){
			trovato=true;
		}
		i++;
	}
	if(trovato==true){
		return (i); //la posizione visiva, (i-1) per l'indice
	}
	else{
		return (-1);
	}

}


int main(){
	int due[n];
	int xx;
	cout<<"inserisci l'array: "<<endl;
	int j=0;
	while(j<n){
		cin>>due[j];
		j++;
	}
	cout<<"inserisci x: "<<endl;
	cin>>xx;
	
	cout<< "ecco la tua posizione di x: "<< posizione(due,xx)<<endl;
}
