#include <iostream>
#include <cmath>
#include <vector>
#include <list>

using namespace std;

/*usando pop_front , push_back
	gestisci la code di gente in un negozio
		il programma legge da tastiera il comando da eseguire:
			1- ESCI , il programma termina
			2- SITUAZIONE, scrivo la fila dei clienti in attesa
			3- SERVITO, servo il primo cliente -->> lo elimino dalla coda
			4- ARRIVA, inserisco il nome di un nuovo cliente in fondo alla fila
*/


int main(){
	string comando;
	list<string> coda;
	cout<<"inserisci comando scegliendo da questi: "<<endl
		<<"1- ESCI , il programma termina"<<endl
		<<"2- SITUAZIONE, scrivo la fila dei clienti in attesa"<<endl
		<<"3- SERVITO, servo il primo cliente -->> lo elimino dalla coda"<<endl
		<<"4- ARRIVA, inserisco il nome di un nuovo cliente in fondo alla fila"<<endl;
	while(comando!="ESCI"){
		
	
			
		cin>>comando;
		
		//traformo tutto in caps
		long unsigned int i=0;
		while(i<comando.length()){
			comando[i]=toupper(comando[i]);
			i++;
		}
		
		
		if(comando=="ARRIVA"){
			string x;
			cout<<"inserisci nome del cliente appena arrivato"<<endl;
			cin>>x;
			coda.push_back(x);
		}
		else if(comando=="SERVITO"){
			
			coda.pop_front();
		}
		else if(comando=="SITUAZIONE"){
						// iteratore it
						//list<string> ::iterator it=coda.begin();
				if(coda.size()!=0){	
					for(string y: coda){
						cout<< y <<", ";
					}
				}
				else{
					cout<<"il negozio è vuoto"<<endl;
				}
			
			cout<<endl;
		}
		
		else{
			cout<<"errore, riprovare"<<endl;
		}
	}
}
